KYAW ZIN THANT + SOE MYAT THU — GITHUB WEDDING WEBSITE
========================================================
Includes:
- index.html
- assets/wedding-invitation.jpg (your invitation card photo)
- assets/wedding-envelope.jpg (your envelope photo)

Existing website:
https://khantzinnthant-byte.github.io/Kyawzinnthant-Soemyatthu-Wedding/
Repository:
https://github.com/khantzinnthant-byte/Kyawzinnthant-Soemyatthu-Wedding

UPLOAD TO YOUR EXISTING REPOSITORY
1. Download and extract this ZIP on your laptop.
2. Open the repository link above and select the Code tab.
3. Click Add file > Upload files.
4. Upload index.html AND the assets folder (keep its name exactly "assets").
   If dragging the folder does not work, open assets and upload both JPG files
   into a folder named assets in the repository.
5. Click Commit changes.
6. Wait a few minutes, then refresh your existing website URL.

No music is included.
The Maps button uses the exact Google Maps link you supplied.
The countdown currently targets midnight at the start of 8 Nov 2026 (Thailand time)
because the ceremony time was not specified. You can change the target date/time
in index.html later if needed.
Do not enter anything in GitHub Pages > Custom domain; leave it blank.
